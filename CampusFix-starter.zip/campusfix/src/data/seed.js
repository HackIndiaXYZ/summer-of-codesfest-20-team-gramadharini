// Category metadata: which team handles it, and the SLA window (hours)
// used to compute each ticket's deadline.
export const CATEGORIES = {
  Electrical: { team: "Electrical Team", slaHours: 6 },
  Plumbing: { team: "Plumbing Team", slaHours: 12 },
  Furniture: { team: "Carpentry Team", slaHours: 48 },
  Cleaning: { team: "Housekeeping", slaHours: 24 },
  Other: { team: "General Facilities", slaHours: 48 },
};

export const STATUSES = ["Submitted", "Assigned", "In Progress", "Resolved"];

const hoursAgo = (h) => new Date(Date.now() - h * 60 * 60 * 1000).toISOString();
const hoursFromNow = (h) => new Date(Date.now() + h * 60 * 60 * 1000).toISOString();

let idCounter = 2031;
export const nextTicketId = () => `WO-${idCounter++}`;

export const seedTickets = [
  {
    id: "WO-2028",
    category: "Electrical",
    block: "Block C",
    room: "204",
    description: "Tube light flickering constantly, strains eyes during evening study hours.",
    status: "In Progress",
    reporter: "Aditi R.",
    createdAt: hoursAgo(4),
    deadline: hoursFromNow(2),
    team: CATEGORIES.Electrical.team,
  },
  {
    id: "WO-2019",
    category: "Plumbing",
    block: "Hostel B",
    room: "Wing 2 Washroom",
    description: "Tap in the common washroom has been leaking continuously since yesterday.",
    status: "Assigned",
    reporter: "Rohan K.",
    createdAt: hoursAgo(3),
    deadline: hoursFromNow(9),
    team: CATEGORIES.Plumbing.team,
  },
  {
    id: "WO-2011",
    category: "Furniture",
    block: "Library",
    room: "Reading Hall 1",
    description: "Two chairs near window row have broken backrests.",
    status: "Submitted",
    reporter: "Meera S.",
    createdAt: hoursAgo(1),
    deadline: hoursFromNow(47),
    team: CATEGORIES.Furniture.team,
  },
  {
    id: "WO-1998",
    category: "Cleaning",
    block: "Block A",
    room: "301",
    description: "Corridor floor left unswept for two days near the lab entrance.",
    status: "Resolved",
    reporter: "Aman T.",
    createdAt: hoursAgo(30),
    deadline: hoursAgo(6),
    resolvedAt: hoursAgo(5),
    team: CATEGORIES.Cleaning.team,
  },
  {
    id: "WO-1990",
    category: "Electrical",
    block: "Hostel A",
    room: "Wing 1 Corridor",
    description: "Corridor light near the stairwell has been out for three days \u2014 safety concern at night.",
    status: "Submitted",
    reporter: "Priya D.",
    createdAt: hoursAgo(9),
    deadline: hoursAgo(3), // already overdue, for demo purposes
    team: CATEGORIES.Electrical.team,
  },
];
