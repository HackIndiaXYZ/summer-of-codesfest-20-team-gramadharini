import { useState } from "react";
import SubmitComplaint from "./SubmitComplaint";
import StatusPipeline from "./StatusPipeline";
import { timeRemaining } from "../lib/utils";
import { CATEGORIES, nextTicketId } from "../data/seed";

export default function StudentView({ tickets, addTicket }) {
  const myName = "Aditi R."; // demo: viewing as this student
  const [expanded, setExpanded] = useState(null);
  const mine = tickets.filter((t) => t.reporter === myName);

  function handleSubmit(form) {
    const meta = CATEGORIES[form.category];
    const now = new Date();
    addTicket({
      id: nextTicketId(),
      ...form,
      reporter: myName,
      status: "Submitted",
      createdAt: now.toISOString(),
      deadline: new Date(now.getTime() + meta.slaHours * 60 * 60 * 1000).toISOString(),
      team: meta.team,
    });
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-5 gap-8">
      <div className="lg:col-span-2">
        <SubmitComplaint onSubmit={handleSubmit} />
      </div>

      <div className="lg:col-span-3">
        <h2 className="font-display text-xl tracking-wide mb-3">MY WORK ORDERS</h2>
        <div className="space-y-3">
          {mine.length === 0 && (
            <p className="text-sm text-[var(--color-muted)] italic">
              Nothing filed yet &mdash; your submitted work orders will appear here.
            </p>
          )}
          {mine.map((t) => {
            const { overdue } = timeRemaining(t.deadline);
            const isOpen = expanded === t.id;
            return (
              <div
                key={t.id}
                className="ticket-tag rounded-r-md rounded-l-sm pl-6 pr-5 py-4 ml-2 cursor-pointer"
                onClick={() => setExpanded(isOpen ? null : t.id)}
              >
                <div className="tear-line absolute left-0 top-2 bottom-2" />
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-xs text-[var(--color-muted)]">{t.id}</span>
                    <span className="text-xs text-[var(--color-muted)]">&middot; {t.category}</span>
                    <span className="text-xs text-[var(--color-muted)]">&middot; {t.block}, {t.room}</span>
                  </div>
                  <span
                    className={`text-xs font-mono ${
                      t.status === "Resolved"
                        ? "text-[var(--color-stamp-green)]"
                        : overdue
                        ? "text-[var(--color-stamp-red)]"
                        : "text-[var(--color-cyan)]"
                    }`}
                  >
                    {t.status}
                  </span>
                </div>
                <p className="text-sm mb-3 pr-2">{t.description}</p>
                {isOpen && (
                  <div className="pt-2 border-t border-[var(--color-line)]">
                    <StatusPipeline current={t.status} overdue={overdue && t.status !== "Resolved"} />
                    <p className="text-xs text-[var(--color-muted)] font-mono mt-2">
                      Assigned team: {t.team}
                    </p>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
