import { useState } from "react";
import { CATEGORIES } from "../data/seed";

export default function SubmitComplaint({ onSubmit }) {
  const [category, setCategory] = useState("Electrical");
  const [block, setBlock] = useState("");
  const [room, setRoom] = useState("");
  const [description, setDescription] = useState("");
  const [photoName, setPhotoName] = useState(null);
  const [justSubmitted, setJustSubmitted] = useState(false);

  const canSubmit = block.trim() && room.trim() && description.trim().length > 8;

  function handleSubmit(e) {
    e.preventDefault();
    if (!canSubmit) return;
    onSubmit({ category, block, room, description, photoName });
    setBlock("");
    setRoom("");
    setDescription("");
    setPhotoName(null);
    setJustSubmitted(true);
    setTimeout(() => setJustSubmitted(false), 2200);
  }

  return (
    <div className="ticket-tag rounded-r-md rounded-l-sm pl-6 pr-5 py-5 ml-2">
      <div className="tear-line absolute left-0 top-2 bottom-2" />
      <h2 className="font-display text-xl tracking-wide mb-1">FILE A WORK ORDER</h2>
      <p className="text-xs text-[var(--color-muted)] mb-4">
        Category, exact location, and a short description &mdash; under a minute.
      </p>

      <form onSubmit={handleSubmit} className="space-y-3">
        <div>
          <label className="block text-xs font-mono text-[var(--color-muted)] mb-1">CATEGORY</label>
          <div className="flex flex-wrap gap-2">
            {Object.keys(CATEGORIES).map((c) => (
              <button
                type="button"
                key={c}
                onClick={() => setCategory(c)}
                className={`text-xs px-2.5 py-1 rounded border font-medium transition ${
                  category === c
                    ? "border-[var(--color-cyan)] bg-[var(--color-cyan)] text-[var(--color-blueprint)]"
                    : "border-[var(--color-line)] text-[var(--color-muted)] hover:border-[var(--color-cyan)]"
                }`}
              >
                {c}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-mono text-[var(--color-muted)] mb-1">BLOCK / HOSTEL</label>
            <input
              value={block}
              onChange={(e) => setBlock(e.target.value)}
              placeholder="e.g. Block C"
              className="w-full bg-[var(--color-blueprint)] border border-[var(--color-line)] rounded px-2.5 py-1.5 text-sm focus:outline-none focus:border-[var(--color-cyan)]"
            />
          </div>
          <div>
            <label className="block text-xs font-mono text-[var(--color-muted)] mb-1">ROOM / AREA</label>
            <input
              value={room}
              onChange={(e) => setRoom(e.target.value)}
              placeholder="e.g. 204"
              className="w-full bg-[var(--color-blueprint)] border border-[var(--color-line)] rounded px-2.5 py-1.5 text-sm focus:outline-none focus:border-[var(--color-cyan)]"
            />
          </div>
        </div>

        <div>
          <label className="block text-xs font-mono text-[var(--color-muted)] mb-1">WHAT'S WRONG</label>
          <textarea
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            rows={3}
            placeholder="Describe the issue clearly..."
            className="w-full bg-[var(--color-blueprint)] border border-[var(--color-line)] rounded px-2.5 py-1.5 text-sm focus:outline-none focus:border-[var(--color-cyan)] resize-none"
          />
        </div>

        <div>
          <label className="block text-xs font-mono text-[var(--color-muted)] mb-1">PHOTO (optional)</label>
          <label className="flex items-center justify-center gap-2 border border-dashed border-[var(--color-line)] rounded px-3 py-3 text-xs text-[var(--color-muted)] cursor-pointer hover:border-[var(--color-cyan)] transition">
            {photoName || "Tap to attach a photo"}
            <input
              type="file"
              accept="image/*"
              className="hidden"
              onChange={(e) => setPhotoName(e.target.files?.[0]?.name || null)}
            />
          </label>
        </div>

        <button
          type="submit"
          disabled={!canSubmit}
          className="w-full bg-[var(--color-cyan)] text-[var(--color-blueprint)] font-semibold text-sm rounded py-2 mt-1 disabled:opacity-40 disabled:cursor-not-allowed hover:brightness-110 transition"
        >
          {justSubmitted ? "Filed \u2713" : "File work order"}
        </button>
      </form>
    </div>
  );
}
