import { STATUS_ORDER } from "../lib/utils";

export default function StatusPipeline({ current, overdue }) {
  const currentIdx = STATUS_ORDER.indexOf(current);

  return (
    <div className="flex items-center">
      {STATUS_ORDER.map((s, i) => {
        const reached = i <= currentIdx;
        const isCurrent = i === currentIdx;
        return (
          <div key={s} className="flex items-center flex-1 last:flex-none">
            <div className="flex flex-col items-center gap-1">
              <div
                className={`h-3.5 w-3.5 rounded-full border-2 ${
                  reached
                    ? isCurrent && overdue
                      ? "bg-[var(--color-stamp-red)] border-[var(--color-stamp-red)]"
                      : "bg-[var(--color-cyan)] border-[var(--color-cyan)]"
                    : "bg-transparent border-[var(--color-muted)]"
                }`}
              />
              <span
                className={`text-[10px] font-mono uppercase tracking-wide ${
                  reached ? "text-[var(--color-ink)]" : "text-[var(--color-muted)]"
                }`}
              >
                {s}
              </span>
            </div>
            {i < STATUS_ORDER.length - 1 && (
              <div
                className="schematic-line flex-1 mx-1 mb-4"
                style={{ opacity: i < currentIdx ? 1 : 0.25 }}
              />
            )}
          </div>
        );
      })}
    </div>
  );
}
