import { useMemo, useState } from "react";
import TicketTag from "./TicketTag";
import { STATUS_ORDER, timeRemaining } from "../lib/utils";
import { CATEGORIES } from "../data/seed";

export default function AdminView({ tickets, advanceTicket }) {
  const [filter, setFilter] = useState("All");

  const filtered = useMemo(
    () => (filter === "All" ? tickets : tickets.filter((t) => t.category === filter)),
    [tickets, filter]
  );

  const overdueCount = tickets.filter(
    (t) => t.status !== "Resolved" && timeRemaining(t.deadline).overdue
  ).length;
  const resolvedCount = tickets.filter((t) => t.status === "Resolved").length;
  const openCount = tickets.length - resolvedCount;

  const byCategory = useMemo(() => {
    const counts = {};
    tickets.forEach((t) => {
      counts[t.category] = (counts[t.category] || 0) + 1;
    });
    return counts;
  }, [tickets]);
  const maxCount = Math.max(1, ...Object.values(byCategory));

  return (
    <div>
      {/* Analytics strip */}
      <div className="grid grid-cols-3 gap-4 mb-8">
        <StatCard label="Open work orders" value={openCount} accent="cyan" />
        <StatCard label="Overdue right now" value={overdueCount} accent="red" />
        <StatCard label="Resolved to date" value={resolvedCount} accent="green" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 mb-8">
        <div className="lg:col-span-3 ticket-tag rounded-md pl-6 pr-5 py-4 ml-2">
          <div className="tear-line absolute left-0 top-2 bottom-2" />
          <h3 className="font-display text-lg tracking-wide mb-3">TICKETS BY CATEGORY</h3>
          <div className="space-y-2">
            {Object.entries(byCategory).map(([cat, count]) => (
              <div key={cat} className="flex items-center gap-3">
                <span className="w-20 text-xs font-mono text-[var(--color-muted)]">{cat}</span>
                <div className="flex-1 h-3 bg-[var(--color-blueprint)] rounded overflow-hidden">
                  <div
                    className="h-full bg-[var(--color-cyan)]"
                    style={{ width: `${(count / maxCount) * 100}%` }}
                  />
                </div>
                <span className="w-4 text-xs font-mono text-right">{count}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="ticket-tag rounded-md pl-6 pr-5 py-4 ml-2">
          <div className="tear-line absolute left-0 top-2 bottom-2" />
          <h3 className="font-display text-lg tracking-wide mb-3">FILTER</h3>
          <div className="flex flex-col gap-1.5">
            {["All", ...Object.keys(CATEGORIES)].map((c) => (
              <button
                key={c}
                onClick={() => setFilter(c)}
                className={`text-left text-xs px-2.5 py-1.5 rounded border transition ${
                  filter === c
                    ? "border-[var(--color-cyan)] bg-[var(--color-cyan)] text-[var(--color-blueprint)]"
                    : "border-[var(--color-line)] text-[var(--color-muted)] hover:border-[var(--color-cyan)]"
                }`}
              >
                {c}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Kanban board */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-5">
        {STATUS_ORDER.map((status) => {
          const col = filtered.filter((t) => t.status === status);
          return (
            <div key={status}>
              <div className="flex items-center justify-between mb-3 px-1">
                <h4 className="font-mono text-xs tracking-widest text-[var(--color-muted)] uppercase">
                  {status}
                </h4>
                <span className="text-xs font-mono text-[var(--color-muted)]">{col.length}</span>
              </div>
              <div className="space-y-3">
                {col.map((t) => (
                  <TicketTag key={t.id} ticket={t} onAdvance={advanceTicket} />
                ))}
                {col.length === 0 && (
                  <p className="text-xs text-[var(--color-muted)] italic pl-2">Empty</p>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function StatCard({ label, value, accent }) {
  const colorMap = {
    cyan: "text-[var(--color-cyan)]",
    red: "text-[var(--color-stamp-red)]",
    green: "text-[var(--color-stamp-green)]",
  };
  return (
    <div className="ticket-tag rounded-md pl-6 pr-5 py-4 ml-2">
      <div className="tear-line absolute left-0 top-2 bottom-2" />
      <p className="text-xs font-mono text-[var(--color-muted)] mb-1 uppercase tracking-wide">{label}</p>
      <p className={`font-display text-4xl ${colorMap[accent]}`}>{value}</p>
    </div>
  );
}
