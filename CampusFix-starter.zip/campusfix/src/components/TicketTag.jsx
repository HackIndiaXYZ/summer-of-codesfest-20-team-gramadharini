import { timeRemaining, relativeAge } from "../lib/utils";

const CATEGORY_DOT = {
  Electrical: "bg-amber-400",
  Plumbing: "bg-cyan-400",
  Furniture: "bg-orange-400",
  Cleaning: "bg-emerald-400",
  Other: "bg-slate-400",
};

export default function TicketTag({ ticket, onAdvance, compact = false }) {
  const isResolved = ticket.status === "Resolved";
  const { overdue, label } = timeRemaining(ticket.deadline);

  return (
    <div className="ticket-tag rounded-r-md rounded-l-sm pl-5 pr-4 py-4 ml-2 shadow-lg shadow-black/30">
      <div className="tear-line absolute left-0 top-2 bottom-2" />

      {/* Rubber stamp overlay for resolved / overdue */}
      {isResolved && (
        <div className="stamp text-[var(--color-stamp-green)] top-2 right-3">
          RESOLVED
        </div>
      )}
      {!isResolved && overdue && (
        <div className="stamp text-[var(--color-stamp-red)] top-2 right-3">
          OVERDUE
        </div>
      )}

      <div className="flex items-center gap-2 mb-1">
        <span className={`h-2 w-2 rounded-full ${CATEGORY_DOT[ticket.category] || "bg-slate-400"}`} />
        <span className="font-mono text-xs text-[var(--color-muted)] tracking-wide">
          {ticket.id}
        </span>
        <span className="text-xs text-[var(--color-muted)]">&middot; {ticket.category}</span>
      </div>

      <p className="text-sm text-[var(--color-ink)] leading-snug mb-2 pr-16">
        {ticket.description}
      </p>

      <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-[var(--color-muted)] font-mono">
        <span>{ticket.block} &middot; {ticket.room}</span>
        <span>filed {relativeAge(ticket.createdAt)}</span>
      </div>

      <div className="mt-3 flex items-center justify-between">
        <span
          className={`text-xs font-mono px-2 py-0.5 rounded border ${
            isResolved
              ? "border-[var(--color-stamp-green)] text-[var(--color-stamp-green)]"
              : overdue
              ? "border-[var(--color-stamp-red)] text-[var(--color-stamp-red)]"
              : "border-[var(--color-cyan)] text-[var(--color-cyan)]"
          }`}
        >
          {isResolved ? `closed ${relativeAge(ticket.resolvedAt)}` : `${overdue ? "overdue by" : "due in"} ${label}`}
        </span>

        {!compact && !isResolved && onAdvance && (
          <button
            onClick={() => onAdvance(ticket.id)}
            className="text-xs font-medium px-2.5 py-1 rounded bg-[var(--color-cyan)] text-[var(--color-blueprint)] hover:brightness-110 transition"
          >
            Advance &rarr;
          </button>
        )}
      </div>
    </div>
  );
}
