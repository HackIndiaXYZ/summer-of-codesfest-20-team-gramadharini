export default function Header({ role, setRole }) {
  return (
    <header className="flex items-center justify-between border-b border-[var(--color-line)] pb-4 mb-8">
      <div className="flex items-center gap-3">
        <div className="h-9 w-9 rounded border-2 border-[var(--color-cyan)] flex items-center justify-center font-mono text-[var(--color-cyan)] text-sm rotate-3">
          WO
        </div>
        <div>
          <h1 className="font-display text-3xl leading-none tracking-wide">
            CAMPUS<span className="text-[var(--color-cyan)]">FIX</span>
          </h1>
          <p className="text-xs text-[var(--color-muted)] font-mono mt-0.5">
            grievance &amp; maintenance work orders
          </p>
        </div>
      </div>

      <div className="flex rounded-md border border-[var(--color-line)] p-1 bg-[var(--color-panel)]">
        {["Student", "Admin"].map((r) => (
          <button
            key={r}
            onClick={() => setRole(r)}
            className={`px-4 py-1.5 rounded text-sm font-medium transition ${
              role === r
                ? "bg-[var(--color-cyan)] text-[var(--color-blueprint)]"
                : "text-[var(--color-muted)] hover:text-[var(--color-ink)]"
            }`}
          >
            {r} view
          </button>
        ))}
      </div>
    </header>
  );
}
